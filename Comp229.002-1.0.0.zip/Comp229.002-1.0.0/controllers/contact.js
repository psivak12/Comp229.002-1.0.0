exports.home = function(req, res, next) {
    res.render('contact', { title: 'Contact Me' });
}

